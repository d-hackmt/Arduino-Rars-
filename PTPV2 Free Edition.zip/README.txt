Thank you for purchasing this pack! You can find the full pack here: https://projektor.gumroad.com/l/noodb

in order to use these tones with your favorite synth, you install them as if they were wavetables.

Follow me Here:
https://www.youtube.com/@projektor_music
https://soundcloud.com/projektor_music
https://open.spotify.com/artist/2uIsTvrokYF3X1BNhbBigy
projektorsound.com